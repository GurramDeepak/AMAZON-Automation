package com.AmazonAutomation.qa.Runners;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features="src\\test\\resources\\Features\\HomePage.feature",glue= {"com.MyAmazonAutomation.qa.StepDefinitions"},
plugin= {"pretty","html:target/HtmlReports/AmazonAutomation69.html","json:target/AmazonAutomation.json",
		"junit:target/AmazonAutomation.xml"},
monochrome =true,publish = true)


public class TestRunner {

}

