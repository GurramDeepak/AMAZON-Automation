package com.AmazonAutomation.qa.PagesObject;

import java.util.List;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.MyAmazonAutomation.qa.StepDefinitions.TestBase;

public class HomePage extends TestBase {

	public WebDriver ldriver;

	public HomePage(WebDriver rdriver) {
	    ldriver = rdriver;
	    PageFactory.initElements(rdriver, this);
	}


	@FindBy(xpath = "//input[@id='twotabsearchtextbox']")
    WebElement SearchBox;
    @FindBy(xpath = "//input[@id='nav-search-submit-button']")
    WebElement SearchBtn;
    @FindBy(xpath = "//a[@id='nav-logo-sprites']")
    WebElement Logo;
    @FindBy(xpath = "//span[@id='nav-search-label-id']")
    WebElement GlobalDropDown;
    @FindBy(xpath = "//div[@id='nav-xshop']/a[6]")
    WebElement NavigationBarCategory;
    @FindBy(xpath = "//div[@id='nav-xshop']/a[12]")
    WebElement NavigationBarCategory1;
    @FindBy(xpath = "//div[@id='nav-xshop']/a[14]")
    WebElement NavigationBarCategory2;


    public void EnterProduct(String product) {
    	SearchBox.sendKeys(product);
    }

    public void ClickSearchButton() {
    	SearchBtn.click();
    }

    public void GoToHomePage() {
    	Logo.click();
    }

    public boolean DefaultDropDown(String defaultValue) {
    	String Default = GlobalDropDown.getText();
    	return Default.contains(defaultValue);
    }

    public void SelectCategory() {
    	NavigationBarCategory.click();
    }

    public boolean VerifyDynamicDropDown() {
    	String NavBarCategory = NavigationBarCategory.getText();
    	String GlobalDropDownCategory = GlobalDropDown.getText();
    	return NavBarCategory.contains(GlobalDropDownCategory);
    }

    public void SelectCatergoryAndSearch(String product) {
    	NavigationBarCategory1.click();
    	SearchBox.sendKeys(product);
    	SearchBtn.click();
    }

    public void SelectUnrelatedCategory() {
    	NavigationBarCategory2.click();
    }

}