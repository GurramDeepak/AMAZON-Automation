package com.AmazonAutomation.qa.Utilities;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class ScreenShot {
    protected WebDriver driver;

    public ScreenShot(WebDriver driver) {
        this.driver = driver;
    }

    public String Time() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss");
        return dateFormat.format(new Date());
    }

    public void takeScreenshot(String tc_no) {
        String fileName = tc_no + "_" + Time() + ".png";

        // Captures the screenshot and save it with the generated file name (TC_date_time)
        File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        try {
            FileUtils.copyFile(scrFile, new File(System.getProperty("user.dir") + "\\Screenshots\\" + fileName));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
