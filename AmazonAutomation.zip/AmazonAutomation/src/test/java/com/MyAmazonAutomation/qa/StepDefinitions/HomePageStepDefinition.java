package com.MyAmazonAutomation.qa.StepDefinitions;

import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import com.AmazonAutomation.qa.PagesObject.HomePage;
import com.AmazonAutomation.qa.Utilities.ScreenShot;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class HomePageStepDefinition extends TestBase {

    private HomePage hp;
    private ScreenShot screenshot;
    private Scenario scenario;

    @Before
    public void setUp(Scenario scenario) {

        setDriver();
        hp = new HomePage(driver);
        screenshot = new ScreenShot(driver);
        this.scenario = scenario;
    }

    @After
    public void tearDown() {
        driver.quit();
    }

    @When("User accesses home page of the website")
    public void userAccessesHomePageOfTheWebsite() {
        hp.GoToHomePage();
    }

    @Then("Dropdown should display {string} by default")
    public void dropdownShouldDisplayByDefault(String defaultValue) {
        hp.DefaultDropDown(defaultValue);
        screenshot.takeScreenshot(scenario.getName());
        assertTrue(hp.DefaultDropDown(defaultValue));
    }

    @When("User selects a category from the navigation bar")
    public void userSelectsFromTheNavigationBar() {
        hp.SelectCategory();
    }

    @Then("Dropdown should be changed to the selected category")
    public void dropdownShouldBeChangedToTheSelectedCategory() {
    	hp.VerifyDynamicDropDown();
    	screenshot.takeScreenshot(scenario.getName());
    	assertTrue(hp.VerifyDynamicDropDown());
    }

    @When("User selects a category from the navigation bar and searches an unrelated product {string}")
    public void user_selects_a_category_from_the_navigation_bar_and_searches_an_unrelated_product(String product) {
    	hp.SelectCatergoryAndSearch(product);
    }

    @Then("Dropdown should become {string}")
    public void dropdown_should_become(String defaultValue) {
    	hp.DefaultDropDown(defaultValue);
    	screenshot.takeScreenshot(scenario.getName());
    	assertTrue(hp.DefaultDropDown(defaultValue));
    }

    @When("User selects Category from the navigation bar a Category not present in the list")
    public void user_selects_category_from_the_navigation_bar_a_category_not_present_in_the_list() {
        hp.SelectUnrelatedCategory();
    }

}