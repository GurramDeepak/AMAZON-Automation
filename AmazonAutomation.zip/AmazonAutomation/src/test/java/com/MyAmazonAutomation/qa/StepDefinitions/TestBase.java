package com.MyAmazonAutomation.qa.StepDefinitions;

import java.time.Duration;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TestBase {

        public WebDriverWait wait;
        public Wait<WebDriver> fwait;
        public WebDriver driver;

        public void setDriver() {
        	System.setProperty( 
        			"webdriver.chrome.driver", 
        			System.getProperty("user.dir")+"\\Driver\\chromedriver.exe"); 
        		WebDriver driver = new ChromeDriver(); 
            wait = new WebDriverWait(driver, Duration.ofSeconds(1));

            fwait = new FluentWait<>(driver)
                    .withTimeout(Duration.ofSeconds(1))
                    .pollingEvery(Duration.ofMillis(30))
                    .ignoring(NoSuchElementException.class);

            driver.get("https://www.amazon.in");

            driver.manage().window().maximize();

            driver.manage().timeouts().implicitlyWait(Duration.ofMinutes(1));
        }
    }